See Chapter 13. It's your call!

And, if you develop something cool, please let us know about it.

We hope that you enjoyed the course!

-- Noam and Shimon

www.nand2tetris.org


And, a message from Aviv:

If you enjoyed this course, here are some recommendations:

- [**`Stanford's compilers course`**](https://www.edx.org/course/compilers) dives deeper into compilers, and guides you in building a modern compiler from scratch! Although our compiler works, it is quite simplistic in comparison.

- [**`Stanford's operating systems`**](https://cs140e.sergio.bz/about/) course covers building an operating system for the Raspberry Pi computer.

- [**`Web Browser Engineering`**](https://browser.engineering/) is a course that shows you how to build a web browser, step-by-step. Web-browsing is maybe the major task people use computers for, so this is quite important.

- [**`Berkeley's Intro2AI course`**](http://ai.berkeley.edu/project_overview.html) is a perfect fit for those of you who liked the tetris part of our course. This course uses very hands-on and visual projects to teach you the basics of Artificial Intelligence.
