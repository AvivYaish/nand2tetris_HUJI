This file is part of nand2tetris, as taught in The Hebrew University,
according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/)

In order to use the nand2tetris software tools, your computer must be equipped
with a Java Run-time Environment. The JRE can be downloaded freely from many
sites including this one: http://java.com/en/download/index.jsp
For best performance, download the latest available version.

Windows users: 
After downloading, put the downloaded zip file in an empty directory on your
computer, and extract its contents as is, without changing the directories
structure and names.

MacOS users:
See the file "Setup Guide for MacOS (written by Yong Bakos).pdf"