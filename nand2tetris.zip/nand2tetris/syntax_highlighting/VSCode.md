See the following plugin: https://marketplace.visualstudio.com/items?itemName=loyio.Nand2Tetris-vscode
