See the following plugin: https://github.com/sevko/vim-nand2tetris-syntax

If you use vim-plug, can easily install with: `Plug 'https://github.com/sevko/vim-nand2tetris-syntax.git'`
